import React from 'react'
import VehicleHero from './Vehicle-page/VehicleHero'

const Vehicle = () => {
  return (
    <VehicleHero/>
  )
}

export default Vehicle
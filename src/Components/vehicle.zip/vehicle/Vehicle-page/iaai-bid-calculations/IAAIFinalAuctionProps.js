export const iaaiEnvironmentalFee = 15.00;
export const iaaiServiceFee = 95.00;

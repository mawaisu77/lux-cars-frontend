 export const copartEnvironmentalFee = 10.00;
 export const copartGateFee = 79.00;
 export const copartTitlePickupFee = 20.00;
